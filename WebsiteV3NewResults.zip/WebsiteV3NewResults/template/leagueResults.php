<?php
require_once __DIR__ . '/header.php';
?>
<div class="mx-auto" style="width: 400px;">
    <h1 class="text-center">Search Leagues</h1>
</div>
<?php
require_once __DIR__ .'/_leagueSearchBar.php';
?>
<br>


<table class="table table-striped table-dark">
    <tr class="text-warning">
        <th> Pos </th>
        <th> Team </th>
        <th> played </th>
        <th> wins </th>
        <th> draws </th>
        <th> losses </th>
        <th> goalsFor </th>
        <th> goalsAgainst </th>
        <th> goalDifference </th>
        <th> points </th>

<?php
foreach ($teamResults as $team):
?>
        <tr>

        <td><?=$team['pos']; ?></td>
        <td><?=$team['teamname']; ?></td>
        <td><?=$team['played']; ?></td>
        <td><?=$team['wins']; ?></td>
        <td><?=$team['draws']; ?></td>
        <td><?=$team['losses']; ?></td>
        <td><?=$team['goalsFor']; ?></td>
        <td><?=$team['goalsAgainst']; ?></td>
        <td><?=$team['goalDifference']; ?></td>
        <td><?=$team['points']; ?></td>
    </tr>
    <?php
    endforeach;
    ?>

</table>


