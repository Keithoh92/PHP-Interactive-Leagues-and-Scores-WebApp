<?php

require_once __DIR__ .'/../template/header.php';
?>

<div class="row">
    <div class="col-6 col-sm-3"><h1>Results</h1></div>

    <div class="w-100"></div>

    <div class="col-6 col-sm-3">
        <p>
            Choose the league you wish to view a team from
        </p>
        <?php
        require_once __DIR__ .'/_resultSearchBar.php';
        ?>
    </div>

</div>