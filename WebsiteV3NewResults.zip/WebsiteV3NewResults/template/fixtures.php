<?php

require_once __DIR__ .'/../template/header.php';
?>

<div class="d-flex p-2 bd-highlight">
    <h1>Fixtures</h1>