<?php

require_once __DIR__ .'/header.php';
?>
<div class="d-flex p-2 bd-highlight">
    This is the place to follow your local leagues








