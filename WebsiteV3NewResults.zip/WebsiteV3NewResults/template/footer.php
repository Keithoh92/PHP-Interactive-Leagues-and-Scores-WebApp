<footer>
    <h1>&#169; Keith O'Hare - Kieran McGrath - Stephen O'Neill</h1>
</footer>

</body>
</html>