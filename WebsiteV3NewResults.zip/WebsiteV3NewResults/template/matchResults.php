<?php
require_once __DIR__ . '/_header.php';
?>
<div class="mx-auto" style="width: 400px;">
    <h1 class="text-center">All results</h1>
</div>
    <table class="table table-striped table-dark">
        <tr class="text-warning">
            <th> ID </th>
            <th> date </th>
            <th> hometeam </th>
            <th> homescore </th>
            <th> awayScore </th>
            <th> awayTeam </th>
            <th> team id </th>


        </tr>
<?php
foreach ($games as $game):
?>
        <tr>
            <td><?= $game->getId() ?></td>
            <td><?= $game->getDate() ?></td>
            <td><?= $game->getHometeam(); ?></td>
            <td><?= $game->getHomescore(); ?></td>
            <td><?= $game->getAwayscore(); ?></td>
            <td><?= $game->getAwayteam(); ?></td>
            <td><?= $game->getTeamid(); ?></td>

        </tr>
<?php
endforeach;
?>