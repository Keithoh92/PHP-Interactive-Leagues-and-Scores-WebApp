<form class="form-inline">
    <div class="form-group">
        <div class = "form-group mx-2">

            <label for="result">Result</label>

        </div>

        <select class = "form-control" name = "result" id="result">
            <option value="">Choose League</option>

            <?php
            foreach($leagues as $league):
                ?>

                <option value="<?= $league->getId(); ?>"><?=$league->getName(); ?></option>

            <?php
            endforeach;
            ?>
        </select>
        <div class="btn-toolbar mx-2">
            <input class="btn btn-info" type="submit" name="action" value="Search Results">
        </div>
    </div>


</form>
<p>

</p>