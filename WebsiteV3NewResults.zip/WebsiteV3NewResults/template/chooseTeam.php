<?php

require_once __DIR__ . '/header.php';
?>
<div class="row">
    <div class="col-6 col-sm-3"><h1>Results</h1></div>

    <div class="w-100"></div>

<form class="form-inline">
    <div class="form-group">
        <div class = "form-group mx-2">

            <label for="result">Teams</label>

        </div>


        <select class = "form-control" name = "team" id = "team">
            <option value="">Choose Team</option>

        <?php
        foreach ($teamResults as $team):
        ?>


        <option value="<?= $team['id'];  ?>" team="<?= $team['id']; ?>"><?= $team['teamname']; ?></option>

    <?php
    endforeach;
    ?>
        </select>
        <div class="btn-toolbar mx-2">
            <input class="btn btn-info" type="submit" name="action" value="Search Team Results">
        </div>
    </div>
</form>



