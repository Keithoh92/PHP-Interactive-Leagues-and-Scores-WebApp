<?php
require_once __DIR__ .'/header.php';
?>

<div class="mx-auto" style="width: 400px;">
    <h1 class="text-center">Search Leagues</h1>
</div>
<?php
require_once __DIR__ .'/_leagueSearchBar.php';
?>
<br>
<h1><?= $league->getName() ?></h1>

    <table class="table table-striped table-dark">
        <tr class="text-warning">
            <th> Pos </th>
            <th> Team </th>
            <th> Pl </th>
            <th> Wins </th>
            <th> Draws </th>
            <th> Losses </th>
            <th> GF </th>
            <th> GA </th>
            <th> GD </th>
            <th> Pts </th>
        </tr>

            <?php
            foreach ($teams as $team):
                ?>

            //takes the teamResults template and loads the relevant fields for the view of the user and puts them in a table
                <tr>
            <td> <?= $team['pos'] ?> </td>
            <td> <?= $team['teamname'] ?></td>
            <td> <?= $team['played'] ?></td>
            <td> <?= $team['wins'] ?></td>
            <td> <?= $team['draws'] ?></td>
            <td> <?= $team['losses'] ?></td>
            <td> <?= $team['goalsFor'] ?></td>
            <td> <?= $team['goalsAgainst'] ?></td>
            <td> <?= $team['goalDifference'] ?></td>
            <td> <?= $team['points'] ?></td>
        </tr>
        <?php
        endforeach;
        ?>
    </table>

