<?php

require_once __DIR__ .'/../template/header.php';
?>

<div class="row">
    <div class="col-6 col-sm-3"><h1>Clubs</h1></div>

    <div class="w-100"></div>

    <div class="col-6 col-sm-3">
    <?php
    require_once __DIR__ .'/_clubSearchBar.php';
    ?>
    </div>

</div>