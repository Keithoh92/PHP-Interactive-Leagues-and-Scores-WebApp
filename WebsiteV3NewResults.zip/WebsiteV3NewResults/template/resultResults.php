<?php
require_once __DIR__ . '/_header.php';
?>
<div class="mx-auto" style="width: 400px;">
    <h1 class="text-center">All Teams</h1>
</div>
    <table class="table table-striped table-dark">
        <tr class="text-warning">
            <th> ID </th>
            <th> teamname </th>
            <th> pos </th>
            <th> played </th>
            <th> wins </th>
            <th> draws </th>
            <th> losses </th>
            <th> goalsFor </th>
            <th> goalsAgainst </th>
            <th> goalDifference </th>
            <th> points </th>
            <th> league id </th>

        </tr>
<?php
foreach ($teams as $team):
?>
        <tr>
            <td><?= $team->getId() ?></td>
            <td><?= $team->getTeamname() ?></td>
            <td><?= $team->getPos(); ?></td>
            <td><?= $team->getPlayed(); ?></td>
            <td><?= $team->getWins(); ?></td>
            <td><?= $team->getDraws(); ?></td>
            <td><?= $team->getLosses(); ?></td>
            <td><?= $team->getGoalsFor(); ?></td>
            <td><?= $team->getGoalsAgainst(); ?></td>
            <td><?= $team->getDifference(); ?></td>
            <td><?= $team->getPoints(); ?></td>
            <td><?= $team->getLeagueid(); ?></td>

        </tr>
<?php
endforeach;
?>