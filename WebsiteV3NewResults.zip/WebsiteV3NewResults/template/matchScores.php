<?php


require_once __DIR__ . '/header.php';
?>
<div class="mx-auto" style="width: 400px;">
    <h1 class="text-center">Search Team Results</h1>
</div>
<?php
require_once __DIR__ .'/_resultSearchBar.php';
?>
<br>


<table class="table table-striped table-dark">
    <tr class="text-warning">
        <th> Date </th>
        <th> Home Team </th>
        <th> - </th>
        <th> - </th>
        <th> Away Team </th>


<?php
foreach ($matchResults as $matchResult):
?>
        <tr>

        <td><?=$matchResult['date']; ?></td>
        <td><?=$matchResult['hometeam']; ?></td>
        <td><?=$matchResult['homescore']; ?></td>
        <td><?=$matchResult['awayscore']; ?></td>
        <td><?=$matchResult['awayteam']; ?></td>

    </tr>
    <?php
    endforeach;
    ?>

</table>