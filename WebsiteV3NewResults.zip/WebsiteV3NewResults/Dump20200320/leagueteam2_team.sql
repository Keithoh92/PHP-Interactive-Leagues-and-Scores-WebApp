-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: leagueteam2
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  `teamname` varchar(45) DEFAULT NULL,
  `pos` int DEFAULT NULL,
  `played` int DEFAULT NULL,
  `wins` int DEFAULT NULL,
  `draws` int DEFAULT NULL,
  `losses` int DEFAULT NULL,
  `goalsFor` int DEFAULT NULL,
  `goalsAgainst` int DEFAULT NULL,
  `goalDifference` int DEFAULT NULL,
  `points` int DEFAULT NULL,
  `leagueid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'Bluebell United',1,11,10,0,1,37,13,24,30,4),(2,'Maynooth University Town FC',2,14,8,5,1,41,17,24,29,4),(3,'Cherry Orchard',3,14,9,2,3,37,18,19,29,4),(4,'Crumlin United FC',4,12,8,3,1,34,12,22,27,4),(5,'UCD AFC',5,15,7,3,5,36,23,13,24,4),(6,'Bangor GG FC',6,12,6,2,4,25,24,1,20,4),(7,'Booth Road Celtic',7,11,5,1,5,31,29,2,16,4),(8,'Ballymun United',8,15,3,2,10,23,45,-22,11,4),(9,'Liffey Wanderers',9,10,3,1,6,14,24,-10,10,4),(10,'Swords Celtic FC',10,11,3,0,8,11,32,-21,9,4),(11,'Colepark United',11,14,3,0,11,19,46,-27,9,4),(12,'St. Patricks',12,15,2,1,12,29,54,-25,7,4),(17,'Malahide United',1,14,11,3,0,44,12,32,36,2),(18,'Home Farm FC',2,13,10,2,1,50,19,31,32,2),(19,'St. Mochtas FC',3,13,9,2,2,36,12,24,29,2),(20,'Wayside Celtic',4,13,6,4,3,34,18,16,22,2),(21,'St. John Bosco',5,11,5,2,4,26,21,5,17,2),(22,'Glebe North',6,13,4,3,6,25,38,-13,15,2),(23,'Tolka Rovers',7,7,4,0,3,14,12,2,12,2),(24,'Dublin Bus',8,14,3,2,9,26,35,-9,11,2),(25,'Tek United',9,12,2,2,8,18,41,-23,8,2),(26,'Glenville FC',10,12,2,1,9,20,40,-20,7,2),(27,'Newtown Rangers AFC',11,9,2,1,6,12,40,-28,7,2),(28,'Templeogue United FC',12,11,2,0,9,19,36,-17,6,2);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-20 14:58:02
