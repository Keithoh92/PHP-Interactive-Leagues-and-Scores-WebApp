<?php
define('DB_HOST', 'localhost:3306');
define('DB_USER', 'root');
define('DB_PASS', 'Brookvill92');
define('DB_NAME', 'leagueteam2');