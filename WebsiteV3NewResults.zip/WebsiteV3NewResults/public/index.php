<?php

require_once __DIR__ .'/../config/db.php';
require_once __DIR__ .'/../vendor/autoload.php';

use Tudublin\MainController;

$action = filter_input(INPUT_GET, 'action');
if(empty($action)){
    $action = filter_input(INPUT_POST, 'action');
}
//The index.php is the front controller and handles all the server requests and responses when the user is navigating the website

$selectedName = filter_input(INPUT_GET, 'league');
$selectedLeagueid = filter_input(INPUT_GET, 'league');
$leagueid = filter_input(INPUT_GET, 'leagueid');
//$selectedTeamname = filter_input(INPUT_GET, 'team');
$selectedTeamid = filter_input(INPUT_GET, 'team');
$selectedTeamName = filter_input(INPUT_GET, 'team');
$teamid = filter_input(INPUT_GET, 'teamid');
//$teamName = filter_input(INPUT_GET, 'teamName');
$teamid = filter_input(INPUT_GET, 'game');


$mainController= new MainController();

switch ($action) {
    case 'leagues':
        $mainController->leaguesPage();//if the user selects the league option in the nav the mainController
        // loads the page
        break;

    case 'clubs'://navbar option does the same as above
        $mainController->clubsPage();
        break;

    case 'Search Leagues'://when league is selected and the user presses the search leagues button - finds the relevant
        // function in mainController - passes the leagueid to this function and the mainController does its business
        //I have commented how the mainController does this in the mainController class
        $mainController->listLeagues($selectedLeagueid);
        break;
    //Same idea as above and for the rest of the switch cases below
    case 'Search Results':
        $mainController->listResults($selectedLeagueid);
        break;

    case 'Search Team Results':
        $mainController->listTeamResults($selectedTeamid);
        break;

    case 'results':
        $mainController->resultsPage();
        break;

    case 'fixtures':
        $mainController->fixturesPage();
        break;

    case 'login':
        $mainController->loginPage();
        break;

    case 'home':
        default:
    $mainController->homesPage();
}