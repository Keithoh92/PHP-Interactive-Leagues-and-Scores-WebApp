<?php
/**
 * Created by PhpStorm.
 * User: eire1
 * Date: 20/02/2020
 * Time: 20:08
 */

namespace Tudublin;


class Game
{
    private $id;
    private $date;
    private $hometeam;
    private $homescore;
    private $awayScore;
    private $teamid;

    /**
     * @return mixed
     */
    public function getTeamid()
    {
        return $this->teamid;
    }

    /**
     * @param mixed $teamid
     */
    public function setTeamid($teamid)
    {
        $this->teamid = $teamid;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getHometeam()
    {
        return $this->hometeam;
    }

    /**
     * @param mixed $hometeam
     */
    public function setHometeam($hometeam)
    {
        $this->hometeam = $hometeam;
    }

    /**
     * @return mixed
     */
    public function getHomescore()
    {
        return $this->homescore;
    }

    /**
     * @param mixed $homescore
     */
    public function setHomescore($homescore)
    {
        $this->homescore = $homescore;
    }

    /**
     * @return mixed
     */
    public function getAwayScore()
    {
        return $this->awayScore;
    }

    /**
     * @param mixed $awayScore
     */
    public function setAwayScore($awayScore)
    {
        $this->awayScore = $awayScore;
    }

    /**
     * @return mixed
     */
    public function getAwayteam()
    {
        return $this->awayteam;
    }

    /**
     * @param mixed $awayteam
     */
    public function setAwayteam($awayteam)
    {
        $this->awayteam = $awayteam;
    }
    private $awayteam;
}