<?php

namespace Tudublin;

class Team
{
    private $id;
    private $teamname;
    private $pos;
    private $played;
    private $wins;
    private $draws;
    private $losses;
    private $goalsFor;
    private $goalsAgainst;
    private $goalDifference;
    private $points;
    private $leagueid;

    /**
     * @return mixed
     */
    public function getLeagueid()
    {
        return $this->leagueid;
    }

    /**
     * @param mixed $leagueid
     */
    public function setLeagueid($leagueid)
    {
        $this->leagueid = $leagueid;
    }

    /**
     * @return mixed
     */
    public function getWins()
    {
        return $this->wins;
    }

    /**
     * @param mixed $wins
     */
    public function setWins($wins)
    {
        $this->wins = $wins;
    }

    /**
     * @return mixed
     */
    public function getDraws()
    {
        return $this->draws;
    }

    /**
     * @param mixed $draws
     */
    public function setDraws($draws)
    {
        $this->draws = $draws;
    }

    /**
     * @return mixed
     */
    public function getLosses()
    {
        return $this->losses;
    }

    /**
     * @param mixed $losses
     */
    public function setLosses($losses)
    {
        $this->losses = $losses;
    }

    /**
     * @return mixed
     */
    public function getPos()
    {
        return $this->pos;
    }

    /**
     * @param mixed $pos
     */
    public function setPos($pos)
    {
        $this->pos = $pos;
    }

    /**
     * @return mixed
     */
    public function getPlayed()
    {
        return $this->played;
    }

    /**
     * @param mixed $played
     */
    public function setPlayed($played)
    {
        $this->played = $played;
    }

    /**
     * @return mixed
     */
    public function getGoalsFor()
    {
        return $this->goalsFor;
    }

    /**
     * @param mixed $goalsFor
     */
    public function setGoalsFor($goalsFor)
    {
        $this->goalsFor = $goalsFor;
    }

    /**
     * @return mixed
     */
    public function getGoalsAgainst()
    {
        return $this->goalsAgainst;
    }

    /**
     * @param mixed $goalsAgainst
     */
    public function setGoalsAgainst($goalsAgainst)
    {
        $this->goalsAgainst = $goalsAgainst;
    }

    /**
     * @return mixed
     */
    public function getGoalDifference()
    {
        return $this->goalDifference;
    }

    /**
     * @param mixed $goalDifference
     */
    public function setGoalDifference($goalDifference)
    {
        $this->goalDifference = $goalDifference;
    }

    /**
     * @return mixed
     */
    public function getPoints()
    {
        return $this->points;
    }

    /**
     * @param mixed $points
     */
    public function setPoints($points)
    {
        $this->points = $points;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->teamname;
    }

    /**
     * @param mixed $teamname
     */
    public function setTeamname($teamname)
    {
        $this->teamname = $teamname;
    }
}