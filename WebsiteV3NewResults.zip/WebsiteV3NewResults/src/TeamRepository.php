<?php


namespace Tudublin;

use Mattsmithdev\PdoCrudRepo\DatabaseTableRepository;

class TeamRepository extends DatabaseTableRepository
{
    //Constructor that connects to the teams database
    public function __construct()
    {
        parent::__construct('Tudublin', 'Team', 'team');
    }

    public function getTeamnameById($teamid)
    {
        $team = $this->getOneById($teamid);
        return $team->getTeamname();//returns teamname given an id
    }
}