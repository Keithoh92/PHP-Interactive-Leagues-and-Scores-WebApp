<?php

namespace Tudublin;

class MainController
{
    private $leagueRepository;
    private $searchController;
    private $teamRepository;
    private $gameRepository;

    public function __construct()
    {
        $this->leagueRepository = new LeagueRepository();
        $this->searchController = new SearchController();
        $this->teamRepository = new TeamRepository();
        $this->gameRepository = new GameRepository();
    }

    function homesPage()
    {
        $pageTitle = 'Homepage';//When homepage is clicked on the nav bar the index.php(Front Controller) handles the request
                                // and points to this function to then load the homepage and pass control back to the index
        $homePageStyle = " active";
        require_once __DIR__ . '/../template/homePage.php';

    }

    function leaguesPage()//loads the leagues page when the leagues button
        //is clicked
    {
        $leagues = $this->leagueRepository->getAll();
        $teams = $this->teamRepository->getAll();

        foreach ($leagues as $league)
        {
            $name = $league->getName();//gets name of all the leagues and displays them in the dropdown menu
        }

        $pageTitle = 'Leagues';
        $leaguesPageStyle = " active";
        require_once __DIR__ . '/../template/leagues.php';

    }

    //When on the leagues page and the user selects a league they wish to view the main controller will be passed
    //the league id of the team selected
    function listLeagues($leagueid)
    {
        $criteria = $this->searchController->toArrayForLeagueSearch($leagueid);//this sends the leagueid to the toArrayForSearch function
        //in the searchController and sets it as the criteria needed to query the database
        $teamResults = $this->searchController->searchLeagues($criteria);//this then sends the criteria(leagueid)
        // to the search leagues function in the searchController and that then queries the database and
        // returns the teams within that league which are then passed to the teamResults page to create a table of team values
        //$leagues =$this->leagueRepository->getAll();
        //$teams = $this->teamRepository->getAll();

        $pageTitle = 'Search Leagues';
        $leaguePageStyle = 'active';
        require_once __DIR__ .'/../template/leagueResults.php';
    }

    function listResults($leagueid)//this loads all the teams in the leage that the user selected
    {
        $criteria = $this->searchController->toArrayForResultsSearch($leagueid);
        $teamResults = $this->searchController->searchResults($criteria);

//      $leagues =$this->leagueRepository->getAll();
//      $teams = $this->teamRepository->getAll();

        $pageTitle = 'Search Results';
        $resultsPageStyle = 'active';
        require_once __DIR__ .'/../template/chooseTeam.php';
    }

    function listTeamResults($teamid)//Takes the teamid selected
    {
        $criteria = $this->searchController->toArrayForListTeams($teamid);//passes teamid to the toArrayForListTeams function
                                        //in searchController and creates the criteria to then be passed below
        //This then sends the criteria to the searchTeams function in SearchController and queries the database and returns
        //the results to the matchResults template that gets all the required fields from the game database table
        $matchResults = $this->searchController->searchTeams($criteria);

//        $teams = $this->teamRepository->getAll();
//        $games = $this->gameRepository->getAll();

        $pageTitle = 'Search Team Results'; //when user selects the team he wishes to view the results of
        // Search team results is selected and passed to the this listTeamResults function - does the business above
        //and then loads the matchScores page with the results of the team selected
        $resultsPageStyle = 'active';
        require_once  __DIR__ .'/../template/matchScores.php';
    }


    function clubsPage()
    {

        $pageTitle = 'Clubs';
        $clubsPageStyle = " active";
        require_once __DIR__ . '/../template/clubs.php';
    }


    function resultsPage()
    {
        $leagues = $this->leagueRepository->getAll();
        $teams = $this->teamRepository->getAll();
        //$matches = $this->matchRepository->getAll();

        foreach ($leagues as $league)
        {
            $name = $league->getName();
        }

        $pageTitle = 'Results';
        $resultsPageStyle = " active";
        require_once __DIR__ . '/../template/results.php';
    }

    function fixturesPage()
    {

        $pageTitle = 'Fixtures';
        $fixturesPageStyle = " active";
        require_once __DIR__ . '/../template/fixtures.php';
    }
    function loginPage()
    {

        $pageTitle = 'Login';
        $fixturesPageStyle = " active";
        require_once __DIR__ . '/../template/login.php';
    }
}