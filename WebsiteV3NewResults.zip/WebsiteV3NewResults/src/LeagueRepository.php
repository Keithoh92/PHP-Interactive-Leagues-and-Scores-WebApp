<?php


namespace Tudublin;

use Mattsmithdev\PdoCrudRepo\DatabaseTableRepository;

class LeagueRepository extends DatabaseTableRepository
{
    public function __construct()
    {
        parent::__construct('Tudublin', 'League', 'league');
    }

    public function getLeagueNameById($leagueid)
    {
        $league = $this->getOneById($leagueid);
        return $league->getName();
    }
}