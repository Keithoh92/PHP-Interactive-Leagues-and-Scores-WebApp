<?php

namespace Tudublin;

use Mattsmithdev\PdoCrudRepo\DatabaseManager;
use PDO;


class SearchController
{
    private $dbm;
    private $connection;

    public function __construct()
    {
        $this->dbm = new DatabaseManager();
        $this->connection = $this->dbm->getDbh();
    }

    public function searchLeagues($criteria)//search leagues bar
    {
        $conditions =$criteria[0];
        $parameters = $criteria[1];

        $sql = "SELECT * FROM league l INNER JOIN team t on l.id = t.leagueid";

        if($conditions){
            $sql .= " WHERE ".implode(" AND ", $conditions);
        }
        $statement = $this->connection->prepare($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $statement->execute($parameters);
        $teams = $statement->fetchAll();
        return $teams;
    }

    public function toArrayForLeagueSearch($leagueid)//take leagueid from maincontroller and set as criteria
    {
        $conditions = [];
        $parameters = [];

        if(!empty($leagueid)){
            $conditions[] = 'leagueid = :leagueid';
            $parameters[":leagueid"] = $leagueid;
        }

        $criteria = [];
        $criteria[] = $conditions;
        $criteria[] = $parameters;

        return $criteria;
    }

    public function searchResults($criteria)//league generator for results search bar
    {
        $conditions =$criteria[0];
        $parameters = $criteria[1];

        $sql = "SELECT * FROM league l INNER JOIN team t on l.id = t.leagueid";

        if($conditions){
            $sql .= " WHERE ".implode(" AND ", $conditions);
        }
        $statement = $this->connection->prepare($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $statement->execute($parameters);
        $teams = $statement->fetchAll();
        return $teams;
    }
    public function toArrayForResultsSearch($leagueid)//takes leagueid from results search bar and passes this value and creates
        //a creates the criteria AKA the leagueid which is then sent back to the main controller function and is then passed to the searchResults function above
        //which then queries the database gets the results and passes them back to the main controller
    {
        $conditions = [];
        $parameters = [];

        if(!empty($leagueid)){
            $conditions[] = 'leagueid = :leagueid';
            $parameters[":leagueid"] = $leagueid;
        }

        $criteria = [];
        $criteria[] = $conditions;
        $criteria[] = $parameters;

        return $criteria;
    }

    //When the user selects a team from the dropdown menu after they have
    //selected a league for which they want to view a teams results - the users selection will be passed to the below
    // function and a queries the database and returns the values returned back to the main controller
    public function searchTeams($criteria)

    {
        $conditions =$criteria[0];
        $parameters = $criteria[1];

        $sql = "SELECT * FROM game g INNER JOIN team t on t.id = g.teamid";

        if($conditions){
            $sql .= " WHERE ".implode(" AND ", $conditions);
        }
        $statement = $this->connection->prepare($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $statement->execute($parameters);
        $games = $statement->fetchAll();
        return $games;
    }

    //takes the selected teamid from the mainController and creates
    //the criteria for searching the database and passes it back to the
    // mainController which will then pass it to the above searchTeams function
    public function toArrayForListTeams($teamid)
    {
        $conditions = [];
        $parameters = [];

        if (!empty($teamid)) {
            $conditions[] = 'teamid = :teamid';
            $parameters[":teamid"] = $teamid;
        }


        $criteria = [];
        $criteria[] = $conditions;
        $criteria[] = $parameters;

        return $criteria;
    }
}