<?php

namespace Tudublin;

class TeamHasGame
{
    private $teamId;
    private $gameId;

    public function getTeam()
    {
        $teamRepository = new TeamRepository();
        $team = $teamRepository->getOneById($this->teamId);

        return $team;
    }

    public function getGame()
    {
        $gameRepository = new GameRepository();
        $game = $gameRepository->getOneById($this->gameId);

        return $game;
    }

    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->teamId;
    }

    /**
     * @param mixed $teamId
     */
    public function setTeamId($teamId)
    {
        $this->teamId = $teamId;
    }

    /**
     * @return mixed
     */
    public function getGameId()
    {
        return $this->gameId;
    }

    /**
     * @param mixed $gameId
     */
    public function setGameId($gameId)
    {
        $this->gameId = $gameId;
    }
}